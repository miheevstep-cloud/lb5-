import sys
from PyQt5.QtWidgets import QApplication
from main_window import MainWindow
from table_window import TableWindow
if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_win = MainWindow()
    table_win = TableWindow()
    main_win.set_table_window(table_win)
    main_win.show()
    sys.exit(app.exec_())