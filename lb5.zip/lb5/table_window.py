
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QLabel, QMessageBox
)
from PyQt5.QtCore import Qt

import csv
import data_reader  
class TableWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Таблица данных")
        self.resize(600, 400)
        self.main_layout = QVBoxLayout(self)
        self.label = QLabel("Данные с датчиков")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("font-size: 16px; font-weight: bold;")
        self.main_layout.addWidget(self.label)
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Температура (°C)", "Влажность (%)", "Освещение (лк)"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.main_layout.addWidget(self.table)
        self.buttons_layout = QHBoxLayout()
        self.btn_read = QPushButton("Считать данные")
        self.btn_save = QPushButton("Сохранить в CSV")
        self.btn_clear = QPushButton("Очистить таблицу")
        self.buttons_layout.addWidget(self.btn_read)
        self.buttons_layout.addWidget(self.btn_save)
        self.buttons_layout.addWidget(self.btn_clear)
        self.main_layout.addLayout(self.buttons_layout)
        self.btn_read.clicked.connect(self.read_data)
        self.btn_save.clicked.connect(self.save_to_csv)
        self.btn_clear.clicked.connect(self.clear_table)
    def read_data(self):
        """
        Считывание данных из модуля data_reader.py
        и добавление новой строки в таблицу.
        """
        values = data_reader.get_data()
        if len(values) == 3:
            row_position = self.table.rowCount()
            self.table.insertRow(row_position)
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row_position, col, item)
        else:
            QMessageBox.warning(self, "Ошибка", "Получены некорректные данные!")
    def save_to_csv(self):
        """Сохранение данных из таблицы в файл data.csv"""
        filename = "data.csv"
        
        try:
            with open(filename, "w", newline="", encoding="utf-8") as csvfile:
                writer = csv.writer(csvfile, delimiter=",")
                writer.writerow(["temperature", "humidity", "light"])
                for row in range(self.table.rowCount()):
                    row_data = []
                    for col in range(self.table.columnCount()):
                        item = self.table.item(row, col)
                        if item is not None:
                            row_data.append(item.text())
                        else:
                            row_data.append("")
                    writer.writerow(row_data)
            
            QMessageBox.information(self, "Успех", f"Данные сохранены в файл {filename}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить файл:\n{e}")
    
    def clear_table(self):
        """Очистка таблицы"""
        self.table.setRowCount(0)