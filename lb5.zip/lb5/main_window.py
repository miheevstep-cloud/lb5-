from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QMainWindow, QPushButton, QVBoxLayout, QWidget, QLabel
from PyQt5.QtCore import Qt
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Система сбора данных с датчиков")
        self.resize(400, 300)
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        self.label_title = QLabel("Система мониторинга")
        self.label_title.setAlignment(Qt.AlignCenter)
        self.label_title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.label_desc = QLabel("приложение для сбора данных с датчиков: \n"
                                 "температура, влажность, освещенность.")
        self.label_desc.setAlignment(Qt.AlignCenter)
        self.label_desc.setWordWrap(True)
        self.btn_open_table = QPushButton("Открыть таблицу данных")
        self.btn_open_table.setStyleSheet(
            "QPushButton { padding: 10px; font-size: 14px; }"
        )
        self.layout.addWidget(self.label_title)
        self.layout.addWidget(self.label_desc)
        self.layout.addWidget(self.btn_open_table)
        self.table_window = None
    def set_table_window(self, table_window):
        """Метод для установки окна таблици(использование в main.py)"""
        self.table_window = table_window
        self.btn_open_table.clicked.connect(self.open_table)
    def open_table(self):
        """Открытие окна с тоблицей"""
        if self.table_window is not None:
            self.table_window.show()