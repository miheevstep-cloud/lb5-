import random
def get_data():
    temperature = random.randint(15, 35)
    humidity = random.randint(30, 95)
    light = random.randint(100, 1500)
    values = [str(temperature), str(humidity), str(light)]
    return values
def parse_data(raw_string):
    return raw_string.split(',')